# SpeedyURLs v2.1.0
Ported [SpeedyURLs](https://github.com/dfgHiatus/SpeedyURLs) to [BepisLoader](https://github.com/ResoniteModding/BepisLoader)